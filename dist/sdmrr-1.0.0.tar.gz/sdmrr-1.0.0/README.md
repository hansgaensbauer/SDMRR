# SDMRR
Software for USRP Based Magnetic Resonance Relaxometer. 

<p align="center">
    <img src="Documentation/spinecho.png" width=70%>
</p>

The transmit and receive functions included with the UHD python API (`send_waveform()`, `recv_num_samps()`, etc) do not work well 
for very long relaxometry experiments, and they do not provide a way to drive the transmit/receive switch. This package provides
lower level utilities for spin-echo and CPMG sequences that use the USRP GPIO to control the T/R switch and the threading library
to handle simultaneous coherent transmit and receive. No modification of the USRP firmware is required.

This library makes extensive use of timed commands to make sure all of the T/R switching and each of the pulses are coherent and cycle-accurate. 

## Setup

### Software Setup

**This package requires the Ettus UHD Driver**, which has to be installed seperately. I recommend [Radioconda](https://github.com/radioconda/radioconda-installer). 

Test the USRP driver using GQRX. Then install the SDMRR wheel into your conda environment with `pip install`.

### Hardware and Low Frequency Systems

Not all USRPs cover low frequencies. For permanent magnet systems, it is necessary to use external mixers to shift the USRP
transmit/receive frequencies to the Larmor Frequency. 

An example system using a B210 is picture below. The transmit and receive mixers should be driven by the same LO to maintain 
coherence.
<p align="center">
    <img src="Documentation/sdmrr-hardware.png" width=70%>
    <img src="Documentation/sdmrr-box.jpg" width=70%>
</p>
By default, the SDMRR class assumes a 120MHz LO, which means the USRP center frequency is 140MHz for a 20MHz (~0.5T) magnet. 

## SDMRR Class Documentation

# Class: `Console`
This class encapsulates functions that interact with the MRC hardware. 

## Attributes

- **`FS`**: (float) – USRP sample rate.
- **`NS`**: (int) – The size of the TX and RX sample buffers.
- **`DEAD_TIME`**: (float) – TX/RX switch dead time in microseconds.
- **`RX_GAIN`**: (int) – USRP RX gain setting (Usually 0-70). 
- **`TUNE_SHIFT`**: (float) – USRP center frequency offset from Larmor frequency (usually about 50kHz)
- **`ZBUFF_TIME`**: (float) – Duration of extra zeros prepended to the transmit waveform to ensure clean startup (usually 40us)
- **`RX_DATA`**: ([np.complex64]) – RX Data buffer
- **`caldict`**: (dictionary) – Calibration data dictionary loaded from cal.json. 


## Methods

### `SDMRR(nocal = False) -> None`
Connect to and initialize the radio. This is the constructor for the SDMRR class. It will attempt to load calibration data from a file `cal.json`.

**Parameters:**
- **`nocal`**: (bool) – Skip automatic calibration sequence, only load old calibration data.

### `SDMRR.onepulse(freq = None, t90 = None, gain = 50, filt = True, start_time = 0.2, amp = 1) -> numpy.ndarray`
Run a single 90 degree pulse and receive data. 

**Parameters:**
- **`freq`**: (int) – The current larmor frequency. 
- **`t90`**: (float) – 90 degree pulse duration.
- **`gain`**: (int) – USRP transmit gain.
- **`filt`**: (bool) – If True, apply a lowpass filter to the data.
- **`start_time`**: (float) – Time (in seconds) from the function call to schedule the start of the pulse. 
- **`amp`**: (float) – Pulse TX amplitude. 

**Returns:**
- **`data`**: (np.ndarray) – Receive data array.

### `SDMRR.pulseecho(freq = None, t90 = None, gain = 70, tr=3e-3, p90p=0, amp90=1, amp180=None) -> numpy.ndarray`
Run a spin-echo experiment. 

**Parameters:**
- **`freq`**: (int) – The current larmor frequency. 
- **`t90`**: (float) – 90 degree pulse duration.
- **`gain`**: (int) – USRP transmit gain.
- **`tr`**: (float) – Time between the 90 and 180 degree pulses.
- **`p90p`**: (float) – Phase (radians) difference for the 90 degree pulse.
- **`amp90`**: (float) – 90 degree pulse TX amplitude. 
- **`amp180`**: (float) – 180 degree pulse TX amplitude. 'None' defaults to amp90.

**Returns:**
- **`data`**: (np.ndarray) – Receive data array.

### `SDMRR.ncpmg(f0 = None, t90 = None, gain = 70, tr=3e-3, npulses = 100, cycle=[0,0,1,3], width=1000, p90p=0, amp90=1, amp180=None) -> numpy.ndarray`
Run a Carr-Purcell-Meiboom-Gill experiment. 

**Parameters:**
- **`f0`**: (int) – The current larmor frequency. 
- **`t90`**: (float) – 90 degree pulse duration.
- **`gain`**: (int) – USRP transmit gain.
- **`tr`**: (float) – Echo spacing.
- **`npulses`**: (int) – Number of echoes.
- **`cycle`**: ([int]) – Internal phase cycle in standard notation (0=0 degrees, 1=90 degrees, etc). 
- **`width`**: (int) – Not used. 
- **`p90p`**: (float) – Phase (radians) difference for the 90 degree pulse.
- **`amp90`**: (float) – 90 degree pulse TX amplitude. 
- **`amp180`**: (float) – 180 degree pulse TX amplitude. 'None' defaults to amp90.

**Returns:**
- **`data`**: (np.ndarray) – Receive data array.

### `SDMRR.cpmg_phaseloop(f0 = None, t90 = None, gain = 70, tr=500.02e-6, npulses = 100, cycle_90 = [0,2,0,2], cycle_180 = [1,1,3,3], amp90=0.45, amp180=0.9, raw=False) -> numpy.ndarray`
Run a series of Carr-Purcell-Meiboom-Gill experiments with an external phase cycle. 

**Parameters:**
- **`f0`**: (int) – The current larmor frequency. 
- **`t90`**: (float) – 90 degree pulse duration.
- **`gain`**: (int) – USRP transmit gain.
- **`tr`**: (float) – Echo spacing.
- **`npulses`**: (int) – Number of echoes.
- **`cycle_90`**: ([int]) – Phases for the 90 degree pulses. 
- **`cycle_180`**: ([int]) – Phases for the 180 degree pulses. 
- **`amp90`**: (float) – 90 degree pulse TX amplitude. 
- **`amp180`**: (float) – 180 degree pulse TX amplitude.
- **`raw`**: (bool) – if True, return the actual RF samples. If False, return the extracted echo amplitudes. 

**Returns:**
- **`data`**: (np.ndarray) – Depending on the value of `raw`, either the RF data or the extracted echo amplitudes. 

### `SDMRR.find_f0(t90 = None, gain = 70, freq = None, debug = False) -> float`
Calibrate the Larmor frequency with a single FID. 

**Parameters:**
- **`t90`**: (float) – 90 degree pulse duration.
- **`gain`**: (int) – USRP transmit gain.
- **`freq`**: (float) – Starting point/initial guess for f0 calibration.
- **`debug`**: (bool) – If true, the value of f0 will be printed.

**Returns:**
- **`f0`**: (float) – The calibrated Larmor frequency.

### `SDMRR.find_t90(f0 = None, gain = 70, debug = False) -> np.ndarray`
Calibrate the 90 degree pulse time with a series of FIDs.

**Parameters:**
- **`f0`**: (float) – Larmor frequency. If `None`, the value from `self.caldict` will be used.
- **`gain`**: (int) – USRP transmit gain.
- **`debug`**: (bool) – If true, the FID amplitudes for each candidate t90 will be printed.

**Returns:**
- **`results`**: (np.ndarray) – np.stack((t90s, scores), axis=1) for each candidate t90 and the resulting FID amplitude.

### `SDMRR.get_t2(cpdata, tr=None) -> float`
Fit an exponential to an array of echo amplitudes and return the corresponding T2.

**Parameters:**
- **`cpdata`**: (np.ndarray) – Either a 2D array, with the first element of dimension 1 is the time for each echo and the second element of dimension 1 is the echo amplitudes, or a 1D array of echo times (see tr)
- **`tr`**: (float) – If `None`, then cpdata is assumed to be 2D. Otherwise, this is the echo spacing in seconds. 

**Returns:**
- **`t2`**: (float) – Best fit T2 value.

### `SDMRR.cal(f0=None, t90=None, debug=False) -> None`
Update the calibration dictionary and json file. Perform a calibration if necessary

**Parameters:**
- **`f0`**: (float) – Larmor frequency. If `None`, a Larmor frequency calibration is performed.
- **`t90`**: (float) – 90 degree pulse duration. If `None`, a pulse duration calibration is performed.
- **`debug`**: (bool) – If true, the value of f0 and the t90 calibration amplitudes will be printed if the respective calibration is required.

### `SDMRR.check_cal(debug=False) -> float`
Check the saved calibration to see if it is up to date. If the last calibration was performed more than 5 minutes ago, repeat the calibration.

**Parameters:**
- **`debug`**: (bool) – If true, the value of f0 and the t90 calibration amplitudes will be printed if the respective calibration is required.

**Returns:**
- **`cal`**: (bool) – True if the last cal was within 5 minutes of the current time.